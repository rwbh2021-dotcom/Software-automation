package appointment;

import java.util.ArrayList;

public class AppointmentService {

	// Stores all appointment in memory
	private ArrayList<Appointment> appointments = new ArrayList<Appointment>();

	// add appointment if ID returned is unique
	public void addAppointment(Appointment appointment) {
		for (Appointment createdAppointment : appointments) {

			if (createdAppointment.getAppointmentId().equals(appointment.getAppointmentId())) {
				throw new IllegalArgumentException("Appointment ID already exists");
			}
		}
		appointments.add(appointment);
	}

	// Appointment id is used to find specific appointment
	private Appointment findAppointment(String appointmentId) {
		for (Appointment appointment : appointments) {

			if (appointment.getAppointmentId().equals(appointmentId)) {
				return appointment;
			}
		}

		throw new IllegalArgumentException("Appointment ID NOT FOUND");
	}

	// Delete appointments by their unique ID
	public void deleteAppointment(String appointmentId) {
		appointments.remove(findAppointment(appointmentId));
	}




}