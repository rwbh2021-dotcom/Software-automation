package appointment;
import java.util.Date;
 //import date

public class Appointment {

	private String appointmentId;
	private Date appointmentDate;
	private String description;

	//constructor validating & storing appointment info
	

	public Appointment(String appointmentId, Date appointmentDate, String description) {
		// Validate and stores appointment information
		//change appointmentDate String to Date

		if (appointmentId == null || appointmentId.length() > 10) {
			throw new IllegalArgumentException("Incorrect Appointment ID");
		}

		if (appointmentDate == null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Date Not Valid");
		} //Replace Date and removed length

		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Incorrect Description, cannot exceed fifty characters");
		}

		this.appointmentId = appointmentId;
		// Register's Appointment ID

		this.appointmentDate = appointmentDate;
		// Register's Date

		this.description = description;
		// Register's Description
	}

	// get methods
	public String getAppointmentId() {
		return appointmentId;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public String getDescription() {
		return description;
	}


}