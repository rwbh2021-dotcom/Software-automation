package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentTest{
	
	@Test
	void appointmentTest() {
		
	
		Date ProceedingDate = new Date(System.currentTimeMillis()+ 86400000);
		//accelerate date by 24hrs (86,400,000 milliseconds)
		
		Appointment appointment = new Appointment 
				("01357", ProceedingDate, "Hair Appointment");
		
		assertTrue(appointment.getAppointmentId().equals("01357"));
		assertTrue(appointment.getAppointmentDate().equals(ProceedingDate));
		assertTrue(appointment.getDescription().equals("Hair Appointment"));
	}
	@Test
	void testAppointmentIdInvalid() {
		Date proceedingDate = new Date(System.currentTimeMillis()+86400000);
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678901", proceedingDate, "Hair Appointment");
		});
	}
	
}
