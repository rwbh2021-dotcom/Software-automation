package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

	class AppointmentServiceTest {

		// Test appointment creation
		@Test

		void testAddAppointment() {
			AppointmentService service = new AppointmentService();

			Date ProceedingDate = new Date(System.currentTimeMillis() +86400000);

			Appointment appointment = new Appointment(
					"01357", ProceedingDate, "Hair Appointment");
			service.addAppointment(appointment);
		}

		// Tests deletion of Appointments
		@Test
		void testDeleteAppointment() {

			AppointmentService service = new AppointmentService();
			
			Date ProceedingDate = new Date(System.currentTimeMillis() +86400000);

			Appointment appointment = new Appointment(
					"01357", ProceedingDate, "Hair Appointment");
			service.addAppointment(appointment);
			service.deleteAppointment("01357");
			assertTrue(true);
		}
		@Test
		void TestDupeAppointmentID() {
			AppointmentService service = new AppointmentService();
			
			Date proceedingDate = new Date(System.currentTimeMillis()+ 86400000);
			
			Appointment appointment1 = 
					new Appointment("01357", proceedingDate, "Hair Appointment");
			Appointment appointment2 =
					new Appointment("01357", proceedingDate, "Nail Appointment");
			
			service.addAppointment(appointment1);
			assertThrows(IllegalArgumentException.class, () -> {
				service.addAppointment(appointment2);
			});
		}
	}
