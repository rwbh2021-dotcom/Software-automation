
public class Contact {

	private String contactId;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	// contact info
	// essential info of contact essential to program

	public Contact(String contactId, String firstName, String lastName, String number, String address) {
		// Validate and stores contact information

		if (contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("Incorrect Contact ID");
		}

		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Incorrect First Name");
		}

		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Incorrect Last Name");
		}

		if (number == null || !number.matches("\\d{10}")) {
			throw new IllegalArgumentException("Incorrect Number");
		}

		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Incorrect Address");
		}

		this.contactId = contactId;
		// Register's ID

		this.firstName = firstName;
		// Register's firstName

		this.lastName = lastName;
		// Register's lastName

		this.number = number;
		// Register's contacts phone number

		this.address = address;
		// Register's contacts address

		// Constructor receieve's data and stores inside object

	}

	// get methods
	public String getContactId() {
		return contactId;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getNumber() {
		return number;
	}

	public String getAddress() {
		return address;
	}

	// set methods
	// used to update fields such as first & last name, phone number and address

	public void setFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Name cannot exceed 10 characters");
		}
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Name cannot exceed 10 characters");
		}
		this.lastName = lastName;
	}

	public void setNumber(String number) {
		if (number == null || !number.matches("\\d{10}")) {
			throw new IllegalArgumentException("Phone Number can only be 10 numbers");
		}
		this.number = number;
	}

	public void setAddress(String address) {
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Address cannot exceed 30 characters");
		}
		this.address = address;
	}

}
