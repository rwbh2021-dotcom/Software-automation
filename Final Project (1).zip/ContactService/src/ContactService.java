import java.util.ArrayList;

public class ContactService {
	// Stores all contacts in memory
	private ArrayList<Contact> contacts = new ArrayList<Contact>();

	// add contact if ID returned is unique
	public void addContact(Contact contact) {
		for (Contact createdContact : contacts) {

			if (createdContact.getContactId().equals(contact.getContactId())) {
				throw new IllegalArgumentException("Contact ID already exists");
			}
		}
		contacts.add(contact);
	}

	// Contact id is used to find specific contact
	private Contact findContact(String contactId) {
		for (Contact contact : contacts) {

			if (contact.getContactId().equals(contactId)) {
				return contact;
			}
		}

		throw new IllegalArgumentException("Contact ID NOT FOUND");
	}

	// Delete contact by their unique ID
	public void deleteContact(String contactId) {
		contacts.remove(findContact(contactId));
	}

	// update first name
	public void updateFirstName(String contactId, String firstName) {
		findContact(contactId).setFirstName(firstName);
	}

	// update last name
	public void updateLastName(String contactId, String lastName) {
		findContact(contactId).setLastName(lastName);
	}

	// update phone number
	public void updateNumber(String contactId, String number) {
		findContact(contactId).setNumber(number);
	}

	// update address
	public void updateAddress(String contactId, String address) {
		findContact(contactId).setAddress(address);
	}

}