import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

	// Test contact Creation
	@Test

	void testAddContact() {
		ContactService service = new ContactService();

		Contact contact = new Contact("01234", "Robert", "Barg", "0123456789", "0000 Main St.");

		service.addContact(contact);

		assertTrue(true);
	}

	// Tests deletion of contact
	@Test
	void testDeleteContact() {

		ContactService service = new ContactService();

		Contact contact = new Contact("01234", "Robert", "Barg", "0123456789", "0000 Main St.");
		service.addContact(contact);
		service.deleteContact("01234");
		assertTrue(true);
	}

	// Test for updating first name
	@Test
	void testUpdateFirstName() {
		ContactService service = new ContactService();

		Contact contact = new Contact("01234", "Robert", "Barg", "0123456789", "0000 Main St.");
		service.addContact(contact);
		service.updateFirstName("01234", "Robert");
		assertTrue(contact.getFirstName().equals("Robert"));
	}
	@Test
	void testDupeContactID() {
		ContactService service = new ContactService();
		
		Contact contact1 = new Contact("01234", "Robert", "Barg", "0123456789", "0000 Main St.");
		
		Contact contact2 = new Contact("01234", "Rob", "Garb", "0000000000", "1111 Main St.");
		
		service.addContact(contact1);
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(contact2);
		});
	}
	@Test
	void testUpdatedLastName() {
		
		ContactService service = new ContactService();
		
		Contact contact = new Contact("01234", "Robert", "Ogunqet", "0123456789", "0000 Main St.");
		
		service.addContact(contact);
		
		service.updateLastName("01234", "Barg");
		
		assertTrue(contact.getLastName().equals("Barg"));
	
	}
}