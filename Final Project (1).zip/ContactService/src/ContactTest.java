import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactTest {
	// Testing Contact Creation
	@Test
	void testContact() {
		Contact contact = new Contact("12345", "Special", "Person", "0123456789", "0000 Main St.");

		assertTrue(contact.getFirstName().equals("Special"));
		assertTrue(contact.getContactId().equals("12345"));
	
	}
	@Test
	void testInvalidContactID() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("54545454545454", "Robert", "Barg", "0123456789", "0000 Main St.");
		});
	}
	@Test
	void testInvalidFirstName() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "NameTooLongToREG", "Barg", "0123456789", "0000 Main St.");
		});
	}
	@Test
	void testInvalidLastName() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Robert", "NameTooLongToREG", "0123456789", "0000 Main St.");
		});
	}
	@Test
	void testInvalidNumber() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Robert", "Barg", "123456789000", "0000 Main St.");
		});
	}
	@Test
	void testInvalidAddress() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Robert", "Barg", "0123456789", null);
		});
	}
	@Test
	void testSetters() {
		Contact contact = new Contact("12345", "Special", "Person", "0123456789", "0000 Main St.");
		
		contact.setFirstName("Robert");
		contact.setLastName("Barg");
		contact.setNumber("0101010101");
		contact.setAddress("1111 Main St.");
		
		assertTrue(contact.getFirstName().equals("Robert"));
		assertTrue(contact.getLastName().equals("Barg"));
		assertTrue(contact.getNumber().equals("0101010101"));
		assertTrue(contact.getAddress().equals("1111 Main St."));
		
	}
}

