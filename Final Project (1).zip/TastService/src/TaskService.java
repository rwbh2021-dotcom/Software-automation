import java.util.ArrayList;

public class TaskService {
	// Stores all tasks in memory
	private ArrayList<Task> tasks = new ArrayList<Task>();

	// add task if ID returned is unique
	public void addTask(Task task) {
		for (Task createdTask : tasks) {

			if (createdTask.getTaskId().equals(task.getTaskId())) {
				throw new IllegalArgumentException("Task ID already exists");
			}
		}
		tasks.add(task);
	}

	// Task id is used to find specific task
	private Task findTask(String taskId) {
		for (Task task : tasks) {

			if (task.getTaskId().equals(taskId)) {
				return task;
			}
		}

		throw new IllegalArgumentException("Task ID NOT FOUND");
	}

	// Delete task by their unique ID
	public void deleteTask(String taskId) {
		tasks.remove(findTask(taskId));
	}

	// update task name
	public void updateName(String taskId, String name) {
		findTask(taskId).setName(name);
	}

	// update task description
	public void updateDescription(String taskId, String description) {
		findTask(taskId).setDescription(description);
	}


}