import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

	// Test task Creation
	@Test

	void testAddContact() {
		TaskService service = new TaskService();

		Task task = new Task("01357", "Take-Home Test", "Finish Test");

		service.addTask(task);

		assertTrue(true);
	}

	// Tests deletion of tasks
	@Test
	void testDeleteTask() {

		TaskService service = new TaskService();

		Task task = new Task("01357", "Take-Home Test", "Finish Test");
		service.addTask(task);
		service.deleteTask("01357");
		assertTrue(true);
	}

	// Test for updating task description
	@Test
	void testUpdateDescription() {
		TaskService service = new TaskService();

		Task task = new Task("01357", "Take-Home Test", "Finish Test");
		service.addTask(task);
		service.updateDescription("01357", "Finish Test");
		assertTrue(task.getDescription().equals("Finish Test"));
	}
	// Test for updating name
	@Test
	void testUpdateName() {
		TaskService service = new TaskService();

		Task task = new Task("01357", "Take-Home Test", "Finish Test");
		service.addTask(task);
		service.updateName("01357", "Project 2, Mod 4");
		assertTrue(task.getName().equals("Project 2, Mod 4"));
	}
	@Test 
	void testDeleteTaskNotFound() {
		TaskService service = new TaskService();
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.deleteTask("99999");
		});
	}

}