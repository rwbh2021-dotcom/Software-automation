
public class Task {

	private String taskId;
	private String name;
	private String description;

	//constructor validating & storing task info
	// I left the logic here for length and almost caused more issues
	//using contact logic, should i have removed these as unnecessary logic?

	public Task(String taskId, String name, String description) {
		// Validate and stores contact information

		if (taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Incorrect Task ID");
		}

		if (name == null || name.length() > 30) {
			throw new IllegalArgumentException("Incorrect Task Name");
		}

		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Incorrect Description");
		}

		this.taskId = taskId;
		// Register's TaskID

		this.name = name;
		// Register's Name

		this.description = description;
		// Register's Description
	}

	// get methods
	public String getTaskId() {
		return taskId;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	// set methods
	// used to update fields

	public void setName(String name) {
		if (name == null || name.length() > 30) {
			throw new IllegalArgumentException("Name cannot exceed 30 characters");
		}
		this.name = name;
	}

	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Description cannot exceed 50 characters");
		}
		this.description = description;
	}

}