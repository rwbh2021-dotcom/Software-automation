import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
	// Testing Task Creation
	@Test
	void testTaskTest() {
		Task task = new Task("01357", "Take-Home Test", "Finish Test");

		assertTrue(task.getTaskId().equals("01357"));
		assertTrue(task.getName().equals("Take-Home Test"));
		assertTrue(task.getDescription().equals("Finish Test"));
	}
	@Test
	void testInvalidTaskID() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task ("12345678901", "Special Person", "Finish Test");
			
		});
	}
	@Test
	void testInvalidTaskNames() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", null, "Finish Test");
		});
	}
}